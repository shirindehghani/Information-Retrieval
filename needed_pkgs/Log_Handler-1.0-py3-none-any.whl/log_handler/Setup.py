# Standard library imports
import logging
import logging.handlers as log_handler
import sys

logger = logging.getLogger("root")
logger.setLevel(logging.INFO)

log_format = logging.Formatter(fmt="%(asctime)s - %(levelname)s - %(message)s", datefmt="%d-%b-%y %H:%M:%S")

# file handler
file_handler = log_handler.RotatingFileHandler("logger.log", mode='w', maxBytes=20 * 1024 * 1024, backupCount=3,
                                               encoding='UTF-8', delay=False)
file_handler.setFormatter(log_format)
logger.addHandler(file_handler)

# stream handler
stream_handler = logging.StreamHandler(sys.stdout)
stream_handler.setFormatter(log_format)
logger.addHandler(stream_handler)
